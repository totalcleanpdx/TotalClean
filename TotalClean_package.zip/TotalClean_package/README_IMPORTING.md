# TotalClean Website & Internal Assets

This package contains a starter structure for your `TotalClean` GitHub repo.

Add these folders and files into the root of https://github.com/totalcleanpdx/TotalClean:

- `website/index.html`
- `internal/dashboard/` (put Dashboard_Mockup.pdf here)
- `internal/ops-binder/` (put Binder_Edition.pdf here)
- `internal/recruiting/` (put Recruiting_Kit.pdf here)
